import { computeSHA256, computeDHash, hammingDistance } from "./hasher.js";

export const MAX_HASH_SIZE = 500 * 1024 * 1024;

export function groupBySize(records) {
  const bySize = new Map();

  for (let i = 0; i < records.length; i++) {
    const record = records[i];
    if (!bySize.has(record.size)) {
      bySize.set(record.size, []);
    }
    bySize.get(record.size).push(record);
  }

  const groups = [];
  for (const group of bySize.values()) {
    if (group.length >= 2) {
      groups.push(group);
    }
  }
  return groups;
}

export function groupByHash(records) {
  const byHash = new Map();

  for (let i = 0; i < records.length; i++) {
    const record = records[i];
    if (!byHash.has(record.sha256)) {
      byHash.set(record.sha256, []);
    }
    byHash.get(record.sha256).push(record);
  }

  const groups = [];
  for (const group of byHash.values()) {
    if (group.length >= 2) {
      groups.push(group);
    }
  }
  return groups;
}

export function splitByHashLimit(records) {
  const hashable = [];
  const tooLarge = [];

  for (let i = 0; i < records.length; i++) {
    if (records[i].size > MAX_HASH_SIZE) {
      tooLarge.push(records[i]);
    } else {
      hashable.push(records[i]);
    }
  }
  return { hashable: hashable, tooLarge: tooLarge };
}

export async function hashFiles(records, onProgress) {
  const hashed = [];
  const couldNotRead = [];

  for (let i = 0; i < records.length; i++) {
    const record = records[i];
    onProgress(i + 1, records.length);
    try {
      const file = await record.fileHandle.getFile();
      record.sha256 = await computeSHA256(file);
      hashed.push(record);
    } catch (error) {
      couldNotRead.push({ path: record.path, reason: error.message });
    }
  }
  return { hashed: hashed, couldNotRead: couldNotRead };
}

export async function findExactDuplicates(records, onProgress) {
  const sizeGroups = groupBySize(records);

  const candidates = [];
  for (let i = 0; i < sizeGroups.length; i++) {
    for (let j = 0; j < sizeGroups[i].length; j++) {
      candidates.push(sizeGroups[i][j]);
    }
  }

  const split = splitByHashLimit(candidates);
  const hashResult = await hashFiles(split.hashable, onProgress);

  return {
    groups: groupByHash(hashResult.hashed),
    hashedCount: hashResult.hashed.length,
    skippedBySizeFilter: records.length - candidates.length,
    tooLarge: split.tooLarge,
    couldNotRead: hashResult.couldNotRead
  };
}

export function pickKeeper(group, mode) {
  let keeper = group[0];

  for (let i = 1; i < group.length; i++) {
    const record = group[i];
    if (mode === "oldest" && record.lastModified < keeper.lastModified) {
      keeper = record;
    }
    if (mode === "newest" && record.lastModified > keeper.lastModified) {
      keeper = record;
    }
    if (mode === "shortest-path" && record.path.length < keeper.path.length) {
      keeper = record;
    }
  }
  return keeper;
}

export function calculateReclaimableBytes(groups) {
  let total = 0;
  for (let i = 0; i < groups.length; i++) {
    total = total + (groups[i].length - 1) * groups[i][0].size;
  }
  return total;
}

export function removeFilesFromList(records, filesToRemove) {
  const remaining = [];
  for (let i = 0; i < records.length; i++) {
    if (!filesToRemove.has(records[i])) {
      remaining.push(records[i]);
    }
  }
  return remaining;
}

export function removeFilesFromGroups(groups, filesToRemove) {
  const remainingGroups = [];
  for (let i = 0; i < groups.length; i++) {
    const remaining = removeFilesFromList(groups[i], filesToRemove);
    if (remaining.length >= 2) {
      remainingGroups.push(remaining);
    }
  }
  return remainingGroups;
}

const IMAGE_EXTENSIONS = ["jpg", "jpeg", "png", "webp", "bmp", "gif"];

export function isImageFile(name) {
  const dotIndex = name.lastIndexOf(".");
  if (dotIndex === -1) {
    return false;
  }
  const extension = name.slice(dotIndex + 1).toLowerCase();
  return IMAGE_EXTENSIONS.includes(extension);
}

export function getImageRecords(records, failedPaths) {
  const images = [];
  for (let i = 0; i < records.length; i++) {
    if (isImageFile(records[i].name) && !failedPaths.has(records[i].path)) {
      images.push(records[i]);
    }
  }
  return images;
}

export async function fingerprintImages(records, onProgress) {
  const fingerprinted = [];
  const couldNotRead = [];

  for (let i = 0; i < records.length; i++) {
    const record = records[i];
    onProgress(i + 1, records.length);
    try {
      const file = await record.fileHandle.getFile();
      record.dhash = await computeDHash(file);
      fingerprinted.push(record);
    } catch (error) {
      couldNotRead.push({ path: record.path, reason: "could not read image: " + error.message });
    }
  }
  return { fingerprinted: fingerprinted, couldNotRead: couldNotRead };
}

export function groupNearDuplicates(images, threshold) {
  const isAssigned = [];
  for (let i = 0; i < images.length; i++) {
    isAssigned.push(false);
  }

  const groups = [];
  for (let i = 0; i < images.length; i++) {
    if (isAssigned[i]) {
      continue;
    }
    const group = [images[i]];
    isAssigned[i] = true;

    for (let j = i + 1; j < images.length; j++) {
      if (!isAssigned[j] && hammingDistance(images[i].dhash, images[j].dhash) <= threshold) {
        group.push(images[j]);
        isAssigned[j] = true;
      }
    }

    if (group.length >= 2) {
      groups.push(group);
    }
  }
  return groups;
}

export function dropExactOnlyGroups(groups) {
  const kept = [];
  for (let i = 0; i < groups.length; i++) {
    if (!allSameHash(groups[i])) {
      kept.push(groups[i]);
    }
  }
  return kept;
}

function allSameHash(group) {
  const firstHash = group[0].sha256;
  if (firstHash === undefined) {
    return false;
  }
  for (let i = 1; i < group.length; i++) {
    if (group[i].sha256 !== firstHash) {
      return false;
    }
  }
  return true;
}

export function findNearDuplicateGroups(images, threshold) {
  return dropExactOnlyGroups(groupNearDuplicates(images, threshold));
}
