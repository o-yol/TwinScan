export async function computeSHA256(file) {
  const buffer = await file.arrayBuffer();
  const digest = await crypto.subtle.digest("SHA-256", buffer);
  return bytesToHex(new Uint8Array(digest));
}

export function bytesToHex(bytes) {
  let hex = "";
  for (let i = 0; i < bytes.length; i++) {
    let part = bytes[i].toString(16);
    if (part.length === 1) {
      part = "0" + part;
    }
    hex = hex + part;
  }
  return hex;
}

export async function computeDHash(file) {
  const bitmap = await createImageBitmap(file);
  try {
    const grays = readGrayPixels(bitmap);
    return buildHashFromGrays(grays);
  } finally {
    bitmap.close();
  }
}

function readGrayPixels(bitmap) {
  const canvas = document.createElement("canvas");
  canvas.width = 9;
  canvas.height = 8;

  const context = canvas.getContext("2d", { willReadFrequently: true });
  context.imageSmoothingQuality = "high";
  context.drawImage(bitmap, 0, 0, 9, 8);

  const pixels = context.getImageData(0, 0, 9, 8).data;
  const grays = [];
  for (let i = 0; i < pixels.length; i += 4) {
    grays.push(0.299 * pixels[i] + 0.587 * pixels[i + 1] + 0.114 * pixels[i + 2]);
  }
  return grays;
}

export function buildHashFromGrays(grays) {
  let high = 0;
  let low = 0;
  let bitNumber = 0;

  for (let row = 0; row < 8; row++) {
    for (let col = 0; col < 8; col++) {
      const left = grays[row * 9 + col];
      const right = grays[row * 9 + col + 1];
      const bit = (left > right) ? 1 : 0;

      if (bitNumber < 32) {
        high = (high << 1) | bit;
      } else {
        low = (low << 1) | bit;
      }
      bitNumber = bitNumber + 1;
    }
  }
  return { high: high >>> 0, low: low >>> 0 };
}

export function popcount(number) {
  let count = 0;
  let remaining = number;

  while (remaining !== 0) {
    count = count + (remaining & 1);
    remaining = remaining >>> 1;
  }
  return count;
}

export function hammingDistance(hashA, hashB) {
  return popcount(hashA.high ^ hashB.high) + popcount(hashA.low ^ hashB.low);
}
