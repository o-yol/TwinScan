import { scanFolder } from "./scanner.js";
import {
  findExactDuplicates, getImageRecords, fingerprintImages, findNearDuplicateGroups,
  pickKeeper, calculateReclaimableBytes, removeFilesFromList, removeFilesFromGroups
} from "./grouper.js";
import {
  formatSize, setControlsEnabled, showBrowserWarning, setStatus, setProgress, hideProgress,
  setThresholdLabel, resetResults, renderSummary, renderGroupSection, renderSkippedLists,
  syncAllCheckboxes, updateActionBar, disableDeleteButton, setActionMessage,
  buildCsvText, downloadTextFile
} from "./ui.js";

const state = {
  records: [],
  exactGroups: [],
  similarGroups: [],
  imageRecords: [],
  zeroByteSkipped: [],
  tooLarge: [],
  couldNotRead: [],
  filesScanned: 0,
  hashedCount: 0,
  skippedBySizeFilter: 0,
  fingerprintedCount: 0,
  threshold: 8,
  seconds: "0.0"
};

function resetState() {
  state.records = [];
  state.exactGroups = [];
  state.similarGroups = [];
  state.imageRecords = [];
  state.zeroByteSkipped = [];
  state.tooLarge = [];
  state.couldNotRead = [];
  state.filesScanned = 0;
  state.hashedCount = 0;
  state.skippedBySizeFilter = 0;
  state.fingerprintedCount = 0;
  state.seconds = "0.0";
}

function init() {
  if (!("showDirectoryPicker" in window)) {
    showBrowserWarning("This tool needs desktop Chrome or Edge.");
    return;
  }

  document.getElementById("scan-button").addEventListener("click", handleScanClick);
  document.getElementById("exact-autoselect").addEventListener("change", function (event) {
    handleAutoSelectChange(event, "exact");
  });
  document.getElementById("similar-autoselect").addEventListener("change", function (event) {
    handleAutoSelectChange(event, "similar");
  });
  document.getElementById("threshold-slider").addEventListener("input", handleThresholdInput);
  document.getElementById("threshold-slider").addEventListener("change", handleThresholdChange);
  document.getElementById("delete-button").addEventListener("click", handleDeleteClick);
  document.getElementById("csv-button").addEventListener("click", handleCsvClick);
}

async function pickFolder() {
  try {
    return await window.showDirectoryPicker({ mode: "readwrite" });
  } catch (error) {
    if (error.name === "AbortError") {
      return null;
    }
    throw error;
  }
}

async function handleScanClick() {
  const folderHandle = await pickFolder();
  if (folderHandle === null) {
    return;
  }

  setControlsEnabled(false);
  resetResults();
  const startTime = performance.now();

  try {
    await runScan(folderHandle, startTime);
  } catch (error) {
    setStatus("Something went wrong: " + error.message);
  } finally {
    hideProgress();
    setControlsEnabled(true);
  }
}

async function runScan(folderHandle, startTime) {
  resetState();
  await scanStep(folderHandle);
  await exactStep();
  await imageStep();
  state.seconds = ((performance.now() - startTime) / 1000).toFixed(1);
  showResults();
}

async function scanStep(folderHandle) {
  setStatus("Scanning...");
  const scanResult = await scanFolder(folderHandle, function (count) {
    setStatus("Scanned " + count + " files...");
  });
  state.records = scanResult.records;
  state.zeroByteSkipped = scanResult.zeroByteSkipped;
  state.couldNotRead = scanResult.couldNotRead;
  state.filesScanned = scanResult.records.length + scanResult.zeroByteSkipped.length;
}

async function exactStep() {
  const exact = await findExactDuplicates(state.records, function (done, total) {
    setStatus("Hashing " + done + " of " + total + " candidate files");
    setProgress(done, total);
  });
  state.exactGroups = exact.groups;
  state.hashedCount = exact.hashedCount;
  state.skippedBySizeFilter = exact.skippedBySizeFilter;
  state.tooLarge = exact.tooLarge;
  state.couldNotRead = state.couldNotRead.concat(exact.couldNotRead);
}

async function imageStep() {
  const failedPaths = collectPaths(state.couldNotRead);
  const images = getImageRecords(state.records, failedPaths);

  const result = await fingerprintImages(images, function (done, total) {
    setStatus("Fingerprinting image " + done + " of " + total);
    setProgress(done, total);
  });
  state.imageRecords = result.fingerprinted;
  state.fingerprintedCount = result.fingerprinted.length;
  state.couldNotRead = state.couldNotRead.concat(result.couldNotRead);

  regroupSimilar();
}

function collectPaths(items) {
  const paths = new Set();
  for (let i = 0; i < items.length; i++) {
    paths.add(items[i].path);
  }
  return paths;
}

function regroupSimilar() {
  state.similarGroups = findNearDuplicateGroups(state.imageRecords, state.threshold);
  linkRecordsToGroups();
}

function linkRecordsToGroups() {
  for (let i = 0; i < state.records.length; i++) {
    state.records[i].exactGroup = null;
    state.records[i].similarGroup = null;
  }
  for (let i = 0; i < state.exactGroups.length; i++) {
    for (let j = 0; j < state.exactGroups[i].length; j++) {
      state.exactGroups[i][j].exactGroup = state.exactGroups[i];
    }
  }
  for (let i = 0; i < state.similarGroups.length; i++) {
    for (let j = 0; j < state.similarGroups[i].length; j++) {
      state.similarGroups[i][j].similarGroup = state.similarGroups[i];
    }
  }
}

function showResults() {
  refreshSummary();
  renderSkippedLists(state.zeroByteSkipped, state.tooLarge, state.couldNotRead);

  if (state.records.length === 0) {
    setStatus("No files to compare in this folder.");
    return;
  }
  renderAllGroups();
  setStatus("Done.");
}

function refreshSummary() {
  renderSummary([
    ["Files scanned", state.filesScanned],
    ["Files hashed", state.hashedCount],
    ["Files skipped by size filter (unique size)", state.skippedBySizeFilter],
    ["Images fingerprinted", state.fingerprintedCount],
    ["Exact-duplicate groups", state.exactGroups.length],
    ["Similar-image groups", state.similarGroups.length],
    ["Reclaimable space (exact duplicates)", formatSize(calculateReclaimableBytes(state.exactGroups))],
    ["Zero-byte files skipped", state.zeroByteSkipped.length],
    ["Too large to hash (over 500 MB)", state.tooLarge.length],
    ["Could not read", state.couldNotRead.length],
    ["Time taken", state.seconds + " seconds"]
  ]);
}

function renderAllGroups() {
  renderGroupSection("exact-section", "exact-groups", state.exactGroups,
    { onToggle: handleToggle }, "No exact duplicates found.");
  renderGroupSection("similar-section", "similar-groups", state.similarGroups,
    { onToggle: handleToggle }, "No similar images found.");
  refreshActionBar();
}

function refreshActionBar() {
  const selected = getSelectedRecords();
  const hasGroups = state.exactGroups.length > 0 || state.similarGroups.length > 0;
  updateActionBar(selected.length, sumSizes(selected), hasGroups);
}

function handleToggle(record, isChecked) {
  if (isChecked === false) {
    record.isSelected = false;
    refreshActionBar();
    return true;
  }

  if (!canTick(record)) {
    return false;
  }
  record.isSelected = true;
  refreshActionBar();
  return true;
}

function canTick(record) {
  if (record.exactGroup && countSelected(record.exactGroup) + 1 >= record.exactGroup.length) {
    return false;
  }
  if (record.similarGroup && countSelected(record.similarGroup) + 1 >= record.similarGroup.length) {
    return false;
  }
  return true;
}

function countSelected(group) {
  let count = 0;
  for (let i = 0; i < group.length; i++) {
    if (group[i].isSelected === true) {
      count = count + 1;
    }
  }
  return count;
}

function getSelectedRecords() {
  const selected = [];
  for (let i = 0; i < state.records.length; i++) {
    const record = state.records[i];
    if (record.isSelected === true && (record.exactGroup || record.similarGroup)) {
      selected.push(record);
    }
  }
  return selected;
}

function sumSizes(records) {
  let total = 0;
  for (let i = 0; i < records.length; i++) {
    total = total + records[i].size;
  }
  return total;
}

function hasFullySelectedGroup(groups) {
  for (let i = 0; i < groups.length; i++) {
    if (countSelected(groups[i]) >= groups[i].length) {
      return true;
    }
  }
  return false;
}

function handleAutoSelectChange(event, sectionName) {
  const mode = event.target.value;
  if (mode === "") {
    return;
  }

  const groups = (sectionName === "exact") ? state.exactGroups : state.similarGroups;
  applyAutoSelect(groups, mode);

  event.target.value = "";
  syncAllCheckboxes();
  refreshActionBar();
}

function applyAutoSelect(groups, mode) {
  for (let i = 0; i < groups.length; i++) {
    for (let j = 0; j < groups[i].length; j++) {
      groups[i][j].isSelected = false;
    }
  }

  for (let i = 0; i < groups.length; i++) {
    const keeper = pickKeeper(groups[i], mode);
    for (let j = 0; j < groups[i].length; j++) {
      if (groups[i][j] !== keeper && canTick(groups[i][j])) {
        groups[i][j].isSelected = true;
      }
    }
  }
}

function handleThresholdInput(event) {
  setThresholdLabel(event.target.value);
}

function handleThresholdChange(event) {
  state.threshold = Number(event.target.value);
  if (state.imageRecords.length === 0) {
    return;
  }

  for (let i = 0; i < state.records.length; i++) {
    state.records[i].isSelected = false;
  }
  regroupSimilar();
  refreshSummary();
  renderAllGroups();
}

async function deleteRecords(records) {
  const deleted = [];
  const failed = [];

  for (let i = 0; i < records.length; i++) {
    const record = records[i];
    try {
      await record.parentHandle.removeEntry(record.name);
      deleted.push(record);
    } catch (error) {
      failed.push({ path: record.path, reason: "could not delete: " + error.message });
    }
  }
  return { deleted: deleted, failed: failed };
}

async function handleDeleteClick() {
  const selected = getSelectedRecords();
  if (selected.length === 0) {
    return;
  }

  if (hasFullySelectedGroup(state.exactGroups) || hasFullySelectedGroup(state.similarGroups)) {
    setActionMessage("Nothing deleted: a group has every copy ticked. Untick one file per group.");
    return;
  }

  const question = "Permanently delete " + selected.length + " files (" + formatSize(sumSizes(selected)) +
    ")?\n\nThis cannot be undone. Deleted files do NOT go to the Recycle Bin.";
  if (!confirm(question)) {
    return;
  }

  await runDeletion(selected);
}

async function runDeletion(selected) {
  setControlsEnabled(false);
  disableDeleteButton();
  setActionMessage("Deleting " + selected.length + " files...");

  try {
    const result = await deleteRecords(selected);
    applyDeletionResult(result);
    setActionMessage("Deleted " + result.deleted.length + " files, " + result.failed.length + " failed.");
  } finally {
    setControlsEnabled(true);
  }
}

function applyDeletionResult(result) {
  const deletedSet = new Set(result.deleted);

  state.records = removeFilesFromList(state.records, deletedSet);
  state.imageRecords = removeFilesFromList(state.imageRecords, deletedSet);
  state.exactGroups = removeFilesFromGroups(state.exactGroups, deletedSet);
  state.similarGroups = removeFilesFromGroups(state.similarGroups, deletedSet);
  state.couldNotRead = state.couldNotRead.concat(result.failed);
  linkRecordsToGroups();

  refreshSummary();
  renderAllGroups();
  renderSkippedLists(state.zeroByteSkipped, state.tooLarge, state.couldNotRead);
}

function handleCsvClick() {
  const csvText = buildCsvText([
    { type: "exact", groups: state.exactGroups },
    { type: "similar", groups: state.similarGroups }
  ]);
  downloadTextFile("twinscan-report.csv", csvText);
}

init();
