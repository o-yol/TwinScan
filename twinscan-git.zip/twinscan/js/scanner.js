export async function scanFolder(rootHandle, onProgress) {
  const result = {
    records: [],
    zeroByteSkipped: [],
    couldNotRead: []
  };

  await walkDirectory(rootHandle, "", result, onProgress);
  onProgress(countSeen(result));
  return result;
}

async function walkDirectory(dirHandle, pathPrefix, result, onProgress) {
  try {
    for await (const [name, handle] of dirHandle.entries()) {
      if (handle.kind === "directory") {
        await walkDirectory(handle, pathPrefix + name + "/", result, onProgress);
      } else {
        await addFile(handle, name, dirHandle, pathPrefix, result);
        reportProgressIfDue(result, onProgress);
      }
    }
  } catch (error) {
    const folderPath = pathPrefix === "" ? "(root folder)" : pathPrefix;
    result.couldNotRead.push({ path: folderPath, reason: error.message });
  }
}

async function addFile(fileHandle, name, parentHandle, pathPrefix, result) {
  const path = pathPrefix + name;
  try {
    const file = await fileHandle.getFile();

    if (file.size === 0) {
      result.zeroByteSkipped.push(path);
      return;
    }

    result.records.push({
      name: name,
      path: path,
      size: file.size,
      lastModified: file.lastModified,
      fileHandle: fileHandle,
      parentHandle: parentHandle,
      isSelected: false
    });
  } catch (error) {
    result.couldNotRead.push({ path: path, reason: error.message });
  }
}

function countSeen(result) {
  return result.records.length + result.zeroByteSkipped.length + result.couldNotRead.length;
}

function reportProgressIfDue(result, onProgress) {
  const seen = countSeen(result);
  if (seen % 50 === 0) {
    onProgress(seen);
  }
}
