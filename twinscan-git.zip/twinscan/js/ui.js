import { isImageFile } from "./grouper.js";

const sectionState = {};

export function formatSize(bytes) {
  const units = ["B", "KB", "MB", "GB", "TB"];
  let value = bytes;
  let unitIndex = 0;

  while (value >= 1024 && unitIndex < units.length - 1) {
    value = value / 1024;
    unitIndex = unitIndex + 1;
  }

  if (unitIndex === 0) {
    return value + " B";
  }
  return value.toFixed(1) + " " + units[unitIndex];
}

export function setControlsEnabled(isEnabled) {
  document.getElementById("scan-button").disabled = !isEnabled;
  document.getElementById("threshold-slider").disabled = !isEnabled;
}

export function showBrowserWarning(message) {
  const warning = document.getElementById("browser-warning");
  warning.textContent = message;
  warning.hidden = false;
  setControlsEnabled(false);
}

export function setStatus(text) {
  document.getElementById("status-text").textContent = text;
}

export function setProgress(done, total) {
  const bar = document.getElementById("progress-bar");
  bar.max = total;
  bar.value = done;
  bar.hidden = false;
}

export function hideProgress() {
  document.getElementById("progress-bar").hidden = true;
}

export function setThresholdLabel(value) {
  document.getElementById("threshold-value").textContent = value;
}

function resetSectionState(sectionId) {
  const old = sectionState[sectionId];
  if (old !== undefined) {
    for (let i = 0; i < old.urls.length; i++) {
      URL.revokeObjectURL(old.urls[i]);
    }
  }
  sectionState[sectionId] = { urls: [], checkboxes: new Map() };
}

export function resetResults() {
  document.getElementById("summary").hidden = true;
  document.getElementById("exact-section").hidden = true;
  document.getElementById("similar-section").hidden = true;
  document.getElementById("skipped-details").hidden = true;
  document.getElementById("actions").hidden = true;
  document.getElementById("action-message").textContent = "";

  document.getElementById("exact-groups").innerHTML = "";
  document.getElementById("similar-groups").innerHTML = "";
  resetSectionState("exact-section");
  resetSectionState("similar-section");
}

export function renderSummary(items) {
  const list = document.getElementById("summary-list");
  list.innerHTML = "";

  for (let i = 0; i < items.length; i++) {
    const li = document.createElement("li");
    li.textContent = items[i][0] + ": " + items[i][1];
    list.appendChild(li);
  }
  document.getElementById("summary").hidden = false;
}

export function renderGroupSection(sectionId, containerId, groups, handlers, emptyMessage) {
  resetSectionState(sectionId);
  const container = document.getElementById(containerId);
  container.innerHTML = "";

  if (groups.length === 0) {
    const message = document.createElement("p");
    message.className = "empty-message";
    message.textContent = emptyMessage;
    container.appendChild(message);
  }

  for (let i = 0; i < groups.length; i++) {
    container.appendChild(buildGroupCard(sectionId, groups[i], i + 1, handlers));
  }
  document.getElementById(sectionId).hidden = false;
}

function buildGroupCard(sectionId, group, groupNumber, handlers) {
  const card = document.createElement("div");
  card.className = "group-card";

  const title = document.createElement("h3");
  title.textContent = "Group " + groupNumber + ": " + group.length + " files" + describeSizes(group);
  card.appendChild(title);

  const message = document.createElement("p");
  message.className = "card-message";
  for (let i = 0; i < group.length; i++) {
    card.appendChild(buildFileRow(sectionId, group[i], handlers, message));
  }
  card.appendChild(message);
  return card;
}

function describeSizes(group) {
  for (let i = 1; i < group.length; i++) {
    if (group[i].size !== group[0].size) {
      return "";
    }
  }
  return ", " + formatSize(group[0].size) + " each";
}

function buildFileRow(sectionId, record, handlers, messageElement) {
  const row = document.createElement("label");
  row.className = "file-row";

  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.checked = record.isSelected === true;
  sectionState[sectionId].checkboxes.set(record, checkbox);
  checkbox.addEventListener("change", function () {
    const accepted = handlers.onToggle(record, checkbox.checked);
    if (accepted) {
      messageElement.textContent = "";
      syncCheckboxes(record);
    } else {
      checkbox.checked = false;
      messageElement.textContent = "Keep at least one copy.";
    }
  });
  row.appendChild(checkbox);

  if (isImageFile(record.name)) {
    row.appendChild(buildThumbnail(sectionId, record));
  }

  const info = document.createElement("div");
  info.appendChild(makeLine("file-name", record.name));
  info.appendChild(makeLine("file-path", "Folder: " + getFolderPath(record)));
  info.appendChild(makeLine("file-meta",
    formatSize(record.size) + " - modified " + new Date(record.lastModified).toLocaleString()));
  row.appendChild(info);
  return row;
}

function buildThumbnail(sectionId, record) {
  const image = document.createElement("img");
  image.className = "thumbnail";
  image.alt = record.name;
  image.loading = "lazy";
  loadThumbnail(sectionId, record, image);
  return image;
}

async function loadThumbnail(sectionId, record, image) {
  try {
    const file = await record.fileHandle.getFile();
    if (!image.isConnected) {
      return;
    }
    const url = URL.createObjectURL(file);
    sectionState[sectionId].urls.push(url);
    image.src = url;
  } catch (error) {

  }
}

export function syncCheckboxes(record) {
  for (const sectionId in sectionState) {
    const checkbox = sectionState[sectionId].checkboxes.get(record);
    if (checkbox !== undefined) {
      checkbox.checked = (record.isSelected === true);
    }
  }
}

export function syncAllCheckboxes() {
  for (const sectionId in sectionState) {
    for (const [record, checkbox] of sectionState[sectionId].checkboxes) {
      checkbox.checked = (record.isSelected === true);
    }
  }
}

function getFolderPath(record) {
  const folder = record.path.slice(0, record.path.length - record.name.length);
  if (folder === "") {
    return "(top folder)";
  }
  return folder;
}

function makeLine(className, text) {
  const line = document.createElement("div");
  line.className = className;
  line.textContent = text;
  return line;
}

export function renderSkippedLists(zeroByte, tooLarge, couldNotRead) {
  const zeroItems = [];
  for (let i = 0; i < zeroByte.length; i++) {
    zeroItems.push(zeroByte[i]);
  }
  const largeItems = [];
  for (let i = 0; i < tooLarge.length; i++) {
    largeItems.push(tooLarge[i].path + " (" + formatSize(tooLarge[i].size) + ")");
  }
  const failedItems = [];
  for (let i = 0; i < couldNotRead.length; i++) {
    failedItems.push(couldNotRead[i].path + " - " + couldNotRead[i].reason);
  }

  fillList("zero-byte-list", zeroItems);
  fillList("too-large-list", largeItems);
  fillList("could-not-read-list", failedItems);
  document.getElementById("skipped-details").hidden = false;
}

function fillList(listId, texts) {
  const list = document.getElementById(listId);
  list.innerHTML = "";

  if (texts.length === 0) {
    texts = ["None"];
  }
  for (let i = 0; i < texts.length; i++) {
    const li = document.createElement("li");
    li.textContent = texts[i];
    list.appendChild(li);
  }
}

export function updateActionBar(selectedCount, selectedBytes, hasGroups) {
  document.getElementById("actions").hidden = false;

  const deleteButton = document.getElementById("delete-button");
  deleteButton.textContent = "Delete " + selectedCount + " selected files (" + formatSize(selectedBytes) + ")";
  deleteButton.disabled = (selectedCount === 0);

  document.getElementById("csv-button").disabled = !hasGroups;
}

export function disableDeleteButton() {
  document.getElementById("delete-button").disabled = true;
}

export function setActionMessage(text) {
  document.getElementById("action-message").textContent = text;
}

export function escapeCsvField(value) {
  const text = String(value);
  return '"' + text.replaceAll('"', '""') + '"';
}

export function buildCsvText(sections) {
  const lines = ["group_type,group_id,path,size_bytes,last_modified,sha256"];

  for (let s = 0; s < sections.length; s++) {
    const groups = sections[s].groups;
    for (let g = 0; g < groups.length; g++) {
      for (let r = 0; r < groups[g].length; r++) {
        lines.push(buildCsvRow(sections[s].type, g + 1, groups[g][r]));
      }
    }
  }
  return lines.join("\n");
}

function buildCsvRow(groupType, groupId, record) {
  const sha = (record.sha256 === undefined) ? "" : record.sha256;
  const fields = [
    groupType,
    groupId,
    record.path,
    record.size,
    new Date(record.lastModified).toISOString(),
    sha
  ];

  const escaped = [];
  for (let i = 0; i < fields.length; i++) {
    escaped.push(escapeCsvField(fields[i]));
  }
  return escaped.join(",");
}

export function downloadTextFile(filename, text) {
  const blob = new Blob([text], { type: "text/csv" });
  const url = URL.createObjectURL(blob);

  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();

  URL.revokeObjectURL(url);
}
